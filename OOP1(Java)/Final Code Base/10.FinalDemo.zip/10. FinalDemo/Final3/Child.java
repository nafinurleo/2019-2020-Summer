import java.lang.*;

public class Child extends FinalDemo
{
	
}