import java.lang.*;

public final class FinalDemo
{
	int a;
	FinalDemo(){
		System.out.println("This is FINALDEMO");
	}
	public void setA(int a){this.a = a;}
	public int getA(){return a;}
	
}