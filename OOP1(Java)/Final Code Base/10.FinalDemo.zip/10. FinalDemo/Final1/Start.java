import java.lang.*;
public class Start
{
	public static void main(String args[])
	{
		FinalAttributeDemo fad2 = new FinalAttributeDemo(20);
		System.out.println();
		fad2.Show();
	}
}