import java.lang.*;

public class Child extends FinalMethodDemo
{

/*
	public void show()
	{
		System.out.println("This is Child");
	}
*/
	
}