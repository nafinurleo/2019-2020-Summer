import java.lang.*;				   

public class Start
{
	public static void main(String []args)
	{
		FileReadWriteDemo file = new FileReadWriteDemo();
		
		file.writeInFile("Rahim 300 7.9.2020","files/History.txt");
		
		
		file.readFromFile("files/History.txt");
	}
}